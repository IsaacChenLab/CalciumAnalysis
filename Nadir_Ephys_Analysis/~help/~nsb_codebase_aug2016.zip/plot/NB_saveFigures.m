% Nadir Bilici
% nadir.bilici@uphs.upenn.edu
% Last edited: July 5, 2016

savefig('CSCPlot.fig');
disp('Saved as Matlab Figure');
saveas(gcf,'CSCPlot','epsc');
disp('Saved as EPS file');
export_fig 'CSCPlot';
disp('Saved as PNG file');
