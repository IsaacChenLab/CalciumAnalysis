% load TTs

[Sc1_TT_Timestamps, Sc1_TT_CellNumbers, Sc1_TT_DataPoints] = importTT ('TT1_cells.ntt');
[Sc2_TT_Timestamps, Sc2_TT_CellNumbers, Sc2_TT_DataPoints] = importTT ('TT2_cells.ntt');
%[Sc3_TT_Timestamps, Sc3_TT_CellNumbers, Sc3_TT_DataPoints] = importTT ('TT3_cells.ntt');
%[Sc4_TT_Timestamps, Sc4_TT_CellNumbers, Sc4_TT_DataPoints] = importTT ('TT4_cells.ntt');
%[Sc5_TT_Timestamps, Sc5_TT_CellNumbers, Sc5_TT_DataPoints] = importTT ('TT5_cells.ntt');
[Sc6_TT_Timestamps, Sc6_TT_CellNumbers, Sc6_TT_DataPoints] = importTT ('TT6_cells.ntt');
%[Sc7_TT_Timestamps, Sc7_TT_CellNumbers, Sc7_TT_DataPoints] = importTT ('TT7_cells.ntt');
[Sc8_TT_Timestamps, Sc8_TT_CellNumbers, Sc8_TT_DataPoints] = importTT ('TT8_cells.ntt');