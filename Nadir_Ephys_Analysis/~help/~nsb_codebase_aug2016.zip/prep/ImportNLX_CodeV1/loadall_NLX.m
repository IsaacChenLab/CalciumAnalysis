%load all NLX files to MATLAB workspace - loadall_NLX.m

LoadCSCs
LoadTTs_v2  %make sure to edit for cells and tets
LoadEVs
LoadVTs