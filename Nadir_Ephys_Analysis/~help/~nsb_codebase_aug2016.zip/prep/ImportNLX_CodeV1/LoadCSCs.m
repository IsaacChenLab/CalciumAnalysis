% load CSCs

% load TTs

if exist ('CSC1.ncs') == 2
    
    [CSC1_Timestamp,CSC1_SampleFrequency,CSC1_Samples] = importCSC('CSC1.ncs');
        
else
end

if exist ('CSC2.ncs') == 2

    [CSC2_Timestamp,CSC2_SampleFrequency,CSC2_Samples] = importCSC('CSC2.ncs');
        
else
end

if exist ('CSC3.ncs') == 2

    [CSC3_Timestamp,CSC3_SampleFrequency,CSC3_Samples] = importCSC('CSC3.ncs');
        
else
end

if exist ('CSC4.ncs') == 2

    [CSC4_Timestamp,CSC4_SampleFrequency,CSC4_Samples] = importCSC('CSC4.ncs');
        
else
end

if exist ('CSC5.ncs') == 2

    [CSC5_Timestamp,CSC5_SampleFrequency,CSC5_Samples] = importCSC('CSC5.ncs');
        
else
end

if exist ('CSC6.ncs') == 2

    [CSC6_Timestamp,CSC6_SampleFrequency,CSC6_Samples] = importCSC('CSC6.ncs');

else
end

if exist ('CSC7.ncs') == 2

    [CSC7_Timestamp,CSC7_SampleFrequency,CSC7_Samples] = importCSC('CSC7.ncs');

else
end

if exist ('CSC8.ncs') == 2

    [CSC8_Timestamp,CSC8_SampleFrequency,CSC8_Samples] = importCSC('CSC8.ncs');

else
end

if exist ('CSC9.ncs') == 2

    [CSC9_Timestamp,CSC9_SampleFrequency,CSC9_Samples] = importCSC('CSC9.ncs');

else
end

if exist ('CSC10.ncs') == 2

    [CSC10_Timestamp,CSC10_SampleFrequency,CSC10_Samples] = importCSC('CSC10.ncs');

else
end

if exist ('CSC11.ncs') == 2

    [CSC11_Timestamp,CSC11_SampleFrequency,CSC11_Samples] = importCSC('CSC11.ncs');

else
end

if exist ('CSC12.ncs') == 2

    [CSC12_Timestamp,CSC12_SampleFrequency,CSC12_Samples] = importCSC('CSC12.ncs');

else
end