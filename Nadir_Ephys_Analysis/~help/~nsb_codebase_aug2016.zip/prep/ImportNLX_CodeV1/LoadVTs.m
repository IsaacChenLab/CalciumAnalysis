% load VTs

[VT_Timestamps, VT_ExtractedX, VT_ExtractedY] = importVT;