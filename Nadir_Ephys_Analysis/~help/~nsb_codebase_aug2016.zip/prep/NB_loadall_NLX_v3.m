% Nadir Bilici
% nadir.bilici@uphs.upenn.edu
% July 5, 2016

% Load all NLX files to MATLAB workspace

% MAC OSX
NB_LoadTTs_v3
NB_LoadEVs_v3
NB_LoadCSCs_v3

% If you are using windows, use NB_loadall_NLX.m