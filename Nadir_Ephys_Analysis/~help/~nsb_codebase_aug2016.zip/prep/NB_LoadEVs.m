% Nadir Bilici
% nadir.bilici@uphs.upenn.edu
% August 2016

% Loads event data into MATLAB workspace
[EV_Timestamps, EV_EventIDs, EV_TTLs, EV_EventStrings] = importEV;

disp ('Imported Events information');