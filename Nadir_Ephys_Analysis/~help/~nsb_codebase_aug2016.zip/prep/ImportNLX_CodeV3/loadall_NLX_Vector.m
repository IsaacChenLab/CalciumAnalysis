%load the last 11 channels recorded with Vector electrode to MATLAB workspace


LoadTTs_Vector  %make sure to edit for cells and tets
LoadEVs_v3
LoadCSCs_Vector
%LoadVTs