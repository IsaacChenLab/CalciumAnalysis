%load all NLX files to MATLAB workspace - loadall_NLX.m


LoadTTs_v3  %make sure to edit for cells and tets
LoadEVs_v3
LoadCSCs_v3
%LoadVTs