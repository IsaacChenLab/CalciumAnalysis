
% load CSCs
    
[CSC1_Timestamp,CSC1_SampleFrequency,CSC1_Samples] = importCSC_v3('CSC1.ncs');

test = importCSC_v3('CSC1.ncs');

disp 'CSC1 loaded'

[CSC2_Timestamp,CSC2_SampleFrequency,CSC2_Samples] = importCSC_v3('CSC2.ncs');

disp 'CSC2 loaded'
       
[CSC3_Timestamp,CSC3_SampleFrequency,CSC3_Samples] = importCSC_v3('CSC3.ncs');

disp 'CSC3 loaded'
        
[CSC4_Timestamp,CSC4_SampleFrequency,CSC4_Samples] = importCSC_v3('CSC4.ncs');

disp 'CSC4 loaded'
        
[CSC5_Timestamp,CSC5_SampleFrequency,CSC5_Samples] = importCSC_v3('CSC5.ncs');

disp 'CSC5 loaded'

[CSC6_Timestamp,CSC6_SampleFrequency,CSC6_Samples] = importCSC_v3('CSC6.ncs');

disp 'CSC6 loaded'
[CSC7_Timestamp,CSC7_SampleFrequency,CSC7_Samples] = importCSC_v3('CSC7.ncs');

disp 'CSC7 loaded'

[CSC8_Timestamp,CSC8_SampleFrequency,CSC8_Samples] = importCSC_v3('CSC8.ncs');

disp 'CSC8 loaded'

[CSC9_Timestamp,CSC9_SampleFrequency,CSC9_Samples] = importCSC_v3('CSC9.ncs');

disp 'CSC9 loaded'

[CSC10_Timestamp,CSC10_SampleFrequency,CSC10_Samples] = importCSC_v3('CSC10.ncs');

disp 'CSC10 loaded'

[CSC11_Timestamp,CSC11_SampleFrequency,CSC11_Samples] = importCSC_v3('CSC11.ncs');

disp 'CSC11 loaded'

[CSC12_Timestamp,CSC12_SampleFrequency,CSC12_Samples] = importCSC_v3('CSC12.ncs');

disp 'CSC12 loaded'
    
[CSC13_Timestamp,CSC13_SampleFrequency,CSC13_Samples] = importCSC_v3('CSC13.ncs');

disp 'CSC13 loaded'
    
[CSC14_Timestamp,CSC14_SampleFrequency,CSC14_Samples] = importCSC_v3('CSC14.ncs');

disp 'CSC14 loaded'
    
[CSC15_Timestamp,CSC15_SampleFrequency,CSC15_Samples] = importCSC_v3('CSC15.ncs');

disp 'CSC15 loaded'
    
[CSC16_Timestamp,CSC16_SampleFrequency,CSC16_Samples] = importCSC_v3('CSC16.ncs');

disp 'CSC16 loaded'
    
[CSC17_Timestamp,CSC17_SampleFrequency,CSC17_Samples] = importCSC_v3('CSC17.ncs');

disp 'CSC17 loaded'
    
[CSC18_Timestamp,CSC18_SampleFrequency,CSC18_Samples] = importCSC_v3('CSC18.ncs');

disp 'CSC18 loaded'
    
[CSC19_Timestamp,CSC19_SampleFrequency,CSC19_Samples] = importCSC_v3('CSC19.ncs');

disp 'CSC19 loaded'
    
[CSC20_Timestamp,CSC20_SampleFrequency,CSC20_Samples] = importCSC_v3('CSC20.ncs');

disp 'CSC20 loaded'

[CSC21_Timestamp,CSC21_SampleFrequency,CSC21_Samples] = importCSC_v3('CSC21.ncs');

disp 'CSC21 loaded'

[CSC22_Timestamp,CSC22_SampleFrequency,CSC22_Samples] = importCSC_v3('CSC22.ncs');

disp 'CSC22 loaded'

[CSC23_Timestamp,CSC23_SampleFrequency,CSC23_Samples] = importCSC_v3('CSC23.ncs');

disp 'CSC23 loaded'

[CSC24_Timestamp,CSC24_SampleFrequency,CSC24_Samples] = importCSC_v3('CSC24.ncs');

disp 'CSC24 loaded'

[CSC25_Timestamp,CSC25_SampleFrequency,CSC25_Samples] = importCSC_v3('CSC25.ncs');

disp 'CSC25 loaded'

[CSC26_Timestamp,CSC26_SampleFrequency,CSC26_Samples] = importCSC_v3('CSC26.ncs');

disp 'CSC26 loaded'

[CSC27_Timestamp,CSC27_SampleFrequency,CSC27_Samples] = importCSC_v3('CSC27.ncs');

disp 'CSC27 loaded'

[CSC28_Timestamp,CSC28_SampleFrequency,CSC28_Samples] = importCSC_v3('CSC28.ncs');

disp 'CSC28 loaded'

[CSC29_Timestamp,CSC29_SampleFrequency,CSC29_Samples] = importCSC_v3('CSC29.ncs');

disp 'CSC29 loaded'

[CSC30_Timestamp,CSC30_SampleFrequency,CSC30_Samples] = importCSC_v3('CSC30.ncs');

disp 'CSC30 loaded'

[CSC31_Timestamp,CSC31_SampleFrequency,CSC31_Samples] = importCSC_v3('CSC31.ncs');

disp 'CSC31 loaded'

[CSC32_Timestamp,CSC32_SampleFrequency,CSC32_Samples] = importCSC_v3('CSC32.ncs');
    
disp 'CSC32 loaded'

[CSC33_Timestamp,CSC33_SampleFrequency,CSC33_Samples] = importCSC_v3('CSC33.ncs');

test = importCSC_v3('CSC33.ncs');

disp 'CSC33 loaded'

[CSC34_Timestamp,CSC34_SampleFrequency,CSC34_Samples] = importCSC_v3('CSC34.ncs');

disp 'CSC34 loaded'
       
[CSC35_Timestamp,CSC35_SampleFrequency,CSC35_Samples] = importCSC_v3('CSC35.ncs');

disp 'CSC35 loaded'
        
[CSC36_Timestamp,CSC36_SampleFrequency,CSC36_Samples] = importCSC_v3('CSC36.ncs');

disp 'CSC36 loaded'
        
[CSC37_Timestamp,CSC37_SampleFrequency,CSC37_Samples] = importCSC_v3('CSC37.ncs');

disp 'CSC37 loaded'

[CSC38_Timestamp,CSC38_SampleFrequency,CSC38_Samples] = importCSC_v3('CSC38.ncs');

disp 'CSC38 loaded'

[CSC39_Timestamp,CSC39_SampleFrequency,CSC39_Samples] = importCSC_v3('CSC39.ncs');

disp 'CSC39 loaded'

[CSC40_Timestamp,CSC40_SampleFrequency,CSC40_Samples] = importCSC_v3('CSC40.ncs');

disp 'CSC40 loaded'

[CSC41_Timestamp,CSC41_SampleFrequency,CSC41_Samples] = importCSC_v3('CSC41.ncs');

disp 'CSC41 loaded'

[CSC42_Timestamp,CSC42_SampleFrequency,CSC42_Samples] = importCSC_v3('CSC42.ncs');

disp 'CSC42 loaded'

[CSC43_Timestamp,CSC43_SampleFrequency,CSC43_Samples] = importCSC_v3('CSC43.ncs');

disp 'CSC43 loaded'

[CSC44_Timestamp,CSC44_SampleFrequency,CSC44_Samples] = importCSC_v3('CSC44.ncs');

disp 'CSC44 loaded'
    
[CSC45_Timestamp,CSC45_SampleFrequency,CSC45_Samples] = importCSC_v3('CSC45.ncs');

disp 'CSC45 loaded'
    
[CSC46_Timestamp,CSC46_SampleFrequency,CSC46_Samples] = importCSC_v3('CSC46.ncs');

disp 'CSC46 loaded'
    
[CSC47_Timestamp,CSC47_SampleFrequency,CSC47_Samples] = importCSC_v3('CSC47.ncs');

disp 'CSC47 loaded'
    
[CSC48_Timestamp,CSC48_SampleFrequency,CSC48_Samples] = importCSC_v3('CSC48.ncs');

disp 'CSC48 loaded'
    
[CSC49_Timestamp,CSC49_SampleFrequency,CSC49_Samples] = importCSC_v3('CSC49.ncs');

disp 'CSC49 loaded'
    
[CSC50_Timestamp,CSC50_SampleFrequency,CSC50_Samples] = importCSC_v3('CSC50.ncs');

disp 'CSC50 loaded'
    
[CSC51_Timestamp,CSC51_SampleFrequency,CSC51_Samples] = importCSC_v3('CSC51.ncs');

disp 'CSC51 loaded'
    
[CSC52_Timestamp,CSC52_SampleFrequency,CSC52_Samples] = importCSC_v3('CSC52.ncs');

disp 'CSC52 loaded'

[CSC53_Timestamp,CSC53_SampleFrequency,CSC53_Samples] = importCSC_v3('CSC53.ncs');

disp 'CSC53 loaded'

[CSC54_Timestamp,CSC54_SampleFrequency,CSC54_Samples] = importCSC_v3('CSC54.ncs');

disp 'CSC54 loaded'

[CSC55_Timestamp,CSC55_SampleFrequency,CSC55_Samples] = importCSC_v3('CSC55.ncs');

disp 'CSC55 loaded'

[CSC56_Timestamp,CSC56_SampleFrequency,CSC56_Samples] = importCSC_v3('CSC56.ncs');

disp 'CSC56 loaded'

[CSC57_Timestamp,CSC57_SampleFrequency,CSC57_Samples] = importCSC_v3('CSC57.ncs');

disp 'CSC57 loaded'

[CSC58_Timestamp,CSC58_SampleFrequency,CSC58_Samples] = importCSC_v3('CSC58.ncs');

disp 'CSC58 loaded'

[CSC59_Timestamp,CSC59_SampleFrequency,CSC59_Samples] = importCSC_v3('CSC59.ncs');

disp 'CSC59 loaded'

[CSC60_Timestamp,CSC60_SampleFrequency,CSC60_Samples] = importCSC_v3('CSC60.ncs');

disp 'CSC60 loaded'

[CSC61_Timestamp,CSC61_SampleFrequency,CSC61_Samples] = importCSC_v3('CSC61.ncs');

disp 'CSC61 loaded'

[CSC62_Timestamp,CSC62_SampleFrequency,CSC62_Samples] = importCSC_v3('CSC62.ncs');

disp 'CSC62 loaded'

[CSC63_Timestamp,CSC63_SampleFrequency,CSC63_Samples] = importCSC_v3('CSC63.ncs');

disp 'CSC63 loaded'

[CSC64_Timestamp,CSC64_SampleFrequency,CSC64_Samples] = importCSC_v3('CSC64.ncs');
    
disp 'CSC64 loaded'