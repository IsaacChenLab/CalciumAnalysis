% LoadEVs

[EV_Timestamps, EV_EventIDs, EV_TTLs, EV_EventStrings] = importEV_v3;