function rez=EF_XCorr (ref, dat, wnd, bin, fs)

wnd=wnd*fs;
rez=zeros(wnd(2)-wnd(1),1);
for i=1:length(ref)
    d=dat(dat>ref(i)+wnd(1))-ref(i)-wnd(1)+1;
    if ~isempty(d(d<wnd(2)-wnd(1)))
        rez(round(d(d<wnd(2)-wnd(1))))=rez(round(d(d<wnd(2)-wnd(1))))+1;
    end
end
rez=rez/length(ref);
if bin>1
    rez=MC_bin(rez,bin);
end