function plotData(src,event)
     plot(event.TimeStamps, event.Data)
     
 end