% 
% addpath c:\MATLAB701\toolbox\meatools\mcintfac;
% addpath(genpath('c:\development\MatSoft\'));
% addpath c:\matlab701\work
% 
% global DATA_DIR;
% DATA_DIR='c:\data';
% cd(DATA_DIR);
% 
% global CAT;
% 
% 
%  
 
 

