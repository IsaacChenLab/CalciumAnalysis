dcat('c378','0711'); 
MC_mcdToMatlab([9:12],1:25);
dcat('c378','0712'); 
MC_mcdToMatlab([12:14],1:25);
dcat('c378','0713'); 
MC_mcdToMatlab([7:13],1:25);
dcat('c378','0714'); 
MC_mcdToMatlab([6:9],1:25);
dcat('c378','0714'); 
MC_mcdToMatlab([10:15],1:25);
dcat('c378','0715'); 
MC_mcdToMatlab([9:14],1:25); 
dcat('c378','0717'); 
MC_mcdToMatlab([13:19],1:25); 
dcat('c378','0718'); 
MC_mcdToMatlab([1:15],1:25);
dcat('c378','0719'); 
MC_mcdToMatlab([1:12],1:25);
dcat('c378','0720'); 
MC_mcdToMatlab([1:13],1:25);
dcat('c378','0721'); 
MC_mcdToMatlab([1:12],1:25);
dcat('c378','0722'); 
MC_mcdToMatlab([1:17],1:25);

dcat('c375','0604');
MC_mcdToMatlab([17 18],1:24);
dcat('c375','0605');
MC_mcdToMatlab([15],1:24);
dcat('c375','0606');
MC_mcdToMatlab([6 7],1:26);
dcat('c375','0607');
MC_mcdToMatlab([15],1:25);
dcat('c375','0608');
MC_mcdToMatlab([11:14],1:25);

dcat('c369');
MC_mcdToMatlab([5 6],1:36);
MC_mcdToMatlab([12 13],1:36);
MC_mcdToMatlab([31 32],1:36);
dcat('c370');
MC_mcdToMatlab([21 22],1:44);
MC_mcdToMatlab([16 17 18],1:44);
dcat('c372');
MC_mcdToMatlab([5:8],1:44);
MC_mcdToMatlab([18 19],1:44);
MC_mcdToMatlab([36:38],1:44);
dcat('c374');
MC_mcdToMatlab([8:11],1:40);
MC_mcdToMatlab([16:19],1:40);
MC_mcdToMatlab([26:29],1:40);



