% dcat('c378','0711'); 
% MC_spPrepareDisplay([9:12],1:25);
% dcat('c378','0712'); 
% MC_spPrepareDisplay([12:14],1:25);
% dcat('c378','0713'); 
% MC_spPrepareDisplay([7:13],1:25);
% dcat('c378','0714'); 
% MC_spPrepareDisplay([6:9],1:25);
% dcat('c378','0714'); 
% MC_spPrepareDisplay([10:15],1:25);
% dcat('c378','0715'); 
% MC_spPrepareDisplay([9:14],1:25); 
% dcat('c378','0717'); 
% MC_spPrepareDisplay([13:19],1:25); 
% dcat('c378','0718'); 
% MC_spPrepareDisplay([1:15],1:25);
% dcat('c378','0719'); 
% MC_spPrepareDisplay([1:12],1:25);
%dcat('c378','0720'); 
%MC_spPrepareDisplay([1:13],1:25);
%dcat('c378','0721'); 
%MC_spPrepareDisplay([1:12],1:25);
%dcat('c378','0722'); 
%MC_spPrepareDisplay([1:17],1:25);

% dcat('c375','0604');
% MC_spPrepareDisplay([17 18],1:24);
% dcat('c375','0605');
% MC_spPrepareDisplay([15],1:24);
% dcat('c375','0606');
% MC_spPrepareDisplay([6 7],1:26);
% dcat('c375','0607');
% MC_spPrepareDisplay([15],1:25);
% dcat('c375','0608');
% MC_spPrepareDisplay([11:14],1:25);
% 
% dcat('c369');
% MC_spPrepareDisplay([5 6],1:36);
% MC_spPrepareDisplay([12 13],1:36);
% MC_spPrepareDisplay([31 32],1:36);
% dcat('c370');
% MC_spPrepareDisplay([21 22],1:44);
% MC_spPrepareDisplay([16 17 18],1:44);
% dcat('c372');
% MC_spPrepareDisplay([5:8],1:44);
% MC_spPrepareDisplay([18 19],1:44);
% MC_spPrepareDisplay([36:38],1:44);
% dcat('c374');
% MC_spPrepareDisplay([8:11],1:40);
% MC_spPrepareDisplay([16:19],1:40);
% MC_spPrepareDisplay([26:29],1:40);
% 


