

% dcat('c380','0910')
% MC_lfpFixPrepareFiles(1:13,1:33);
dcat('c380','0909')
MC_lfpFixPrepareFiles(1:18,1:33);
dcat('c380','0908')
MC_lfpFixPrepareFiles(5:17,1:33);
dcat('c380','0907')
MC_lfpFixPrepareFiles(2:19,1:33);
dcat('c380','0906')
MC_lfpFixPrepareFiles(2:21,1:33);
dcat('c380','0905')
MC_lfpFixPrepareFiles(1:19,1:33);
dcat('c380','0903')
MC_lfpFixPrepareFiles(1:18,1:33);
dcat('c380','0902')
MC_lfpFixPrepareFiles([1:9 13:18],1:33);
dcat('c380','0901')
MC_lfpFixPrepareFiles(1:17,1:33);
dcat('c380','0831')
MC_lfpFixPrepareFiles(5:8,1:33);
